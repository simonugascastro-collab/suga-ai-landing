import { GoogleGenAI, Type, Schema } from "@google/genai";

// Define the interface for the generated response
export interface GeneratedPreview {
  headline: string;
  subheadline: string;
  primaryColor: string;
  ctaText: string;
  featureList: string[];
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateLandingContent = async (businessDescription: string): Promise<GeneratedPreview> => {
  
  const schema: Schema = {
    type: Type.OBJECT,
    properties: {
      headline: { type: Type.STRING, description: "A catchy, short headline for the hero section." },
      subheadline: { type: Type.STRING, description: "A persuasive subheadline explaining the value proposition." },
      primaryColor: { type: Type.STRING, description: "A hex color code suitable for this business type." },
      ctaText: { type: Type.STRING, description: "A call to action button text." },
      featureList: {
        type: Type.ARRAY,
        items: { type: Type.STRING },
        description: "3 short key benefits or features."
      }
    },
    required: ["headline", "subheadline", "primaryColor", "ctaText", "featureList"]
  };

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-latest',
      contents: `Generate landing page content for a business described as: "${businessDescription}". Make it professional and sales-oriented. Keep it in Spanish.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: schema,
        temperature: 0.7
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI");
    
    return JSON.parse(text) as GeneratedPreview;
  } catch (error) {
    console.error("Error generating content:", error);
    // Fallback in case of error (or missing API key in dev)
    return {
      headline: "Tu Negocio al Siguiente Nivel",
      subheadline: "Creamos la presencia digital que tu empresa merece. Soluciones modernas y efectivas.",
      primaryColor: "#2563eb",
      ctaText: "Contáctanos",
      featureList: ["Diseño Moderno", "Rápido y Seguro", "Atención 24/7"]
    };
  }
};