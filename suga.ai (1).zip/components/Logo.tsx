import React from 'react';

export const Logo: React.FC<{ className?: string }> = ({ className }) => (
  <svg 
    viewBox="0 0 100 100" 
    fill="none" 
    xmlns="http://www.w3.org/2000/svg" 
    className={className}
    aria-label="suga.ai Logo"
  >
    <defs>
      <linearGradient id="brandGradient" x1="10%" y1="100%" x2="90%" y2="0%">
        <stop offset="0%" stopColor="#2563eb" /> {/* brand-600 */}
        <stop offset="100%" stopColor="#60a5fa" /> {/* brand-400 */}
      </linearGradient>
    </defs>
    
    {/* Base 'G' / Link shape */}
    <path 
      d="M48 24C34.7 24 24 34.7 24 48C24 61.3 34.7 72 48 72H68V58H48C42.5 58 38 53.5 38 48C38 42.5 42.5 38 48 38H58L72 24H48Z" 
      fill="url(#brandGradient)" 
    />
    
    {/* Arrow/Growth Indicator */}
    <path 
      d="M66 32L82 16L84 34L66 32Z" 
      fill="url(#brandGradient)" 
    />
    <path 
      d="M82 16L64 16L82 34V16Z" 
      fill="url(#brandGradient)" 
    />
  </svg>
);

export default Logo;