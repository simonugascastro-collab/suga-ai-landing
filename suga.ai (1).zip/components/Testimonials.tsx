import React from 'react';
import { Quote, Star } from 'lucide-react';

const Testimonials: React.FC = () => {
  const testimonials = [
    {
      quote: "Gracias a la landing page ahora recibo consultas todos los días por WhatsApp.",
      author: "Emprendedor local",
      role: "Rubro servicios"
    },
    {
      quote: "Me entregaron la página rápido y el proceso fue simple y claro.",
      author: "Dueño de cafetería",
      role: "Independiente"
    },
    {
      quote: "Ahora tengo presencia digital profesional y mis clientes me encuentran más fácil.",
      author: "Negocio local",
      role: "Atención al público"
    }
  ];

  return (
    <section className="py-24 bg-white border-t border-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold text-slate-900 mb-4">Lo que dicen nuestros clientes</h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((t, index) => (
            <div key={index} className="bg-slate-50 p-8 rounded-2xl border border-slate-100 relative">
              <Quote className="w-10 h-10 text-brand-200 absolute top-6 right-6" />
              <div className="flex space-x-1 mb-6">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                ))}
              </div>
              <p className="text-slate-700 text-lg mb-6 italic relative z-10">"{t.quote}"</p>
              <div>
                <p className="font-bold text-slate-900">{t.author}</p>
                <p className="text-sm text-slate-500">{t.role}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;