import React from 'react';
import Logo from './Logo';

const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-900 text-slate-400 py-12 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 text-center flex flex-col items-center">
        <div className="flex items-center gap-2 mb-4">
           {/* Logo rendered small as requested */}
           <Logo className="h-8 w-8" />
           <span className="text-white text-xl font-bold">suga.ai</span>
        </div>
        <p className="mb-8">Digitalizando negocios locales, uno a la vez.</p>
        <div className="text-sm">
          &copy; {new Date().getFullYear()} suga.ai. Todos los derechos reservados.
        </div>
      </div>
    </footer>
  );
};

export default Footer;