import React from 'react';
import { Smartphone, Zap, TrendingUp, MessageCircle } from 'lucide-react';

const benefits = [
  {
    icon: TrendingUp,
    title: "Más clientes potenciales",
    description: "Diseño optimizado para guiar al usuario hacia la compra o contacto.",
    image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=600&q=80"
  },
  {
    icon: Smartphone,
    title: "Presencia digital profesional",
    description: "Tu negocio se verá increíble en móviles, tablets y computadoras.",
    image: "https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=600&q=80"
  },
  {
    icon: MessageCircle,
    title: "Integración con WhatsApp",
    description: "Tus clientes podrán contactarte directamente con un solo clic.",
    image: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=600&q=80"
  },
  {
    icon: Zap,
    title: "Rápidos y simples",
    description: "Sitios optimizados para cargar al instante. Sin esperas.",
    image: "https://images.unsplash.com/photo-1550439062-609e1531270e?auto=format&fit=crop&w=600&q=80"
  }
];

const Benefits: React.FC = () => {
  return (
    <section id="beneficios" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold text-slate-900 mb-4">Por qué elegirnos</h2>
          <p className="text-lg text-slate-600 max-w-2xl mx-auto">
            Creamos herramientas digitales que trabajan por ti. No es solo una web, es tu mejor vendedor 24/7.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 lg:gap-16">
          {benefits.map((benefit, index) => (
            <div key={index} className="flex flex-col lg:flex-row gap-6 items-center lg:items-start group">
              <div className="w-full lg:w-1/2 relative overflow-hidden rounded-xl shadow-lg border border-slate-100">
                <div className="absolute inset-0 bg-brand-600/10 group-hover:bg-transparent transition-colors duration-300"></div>
                <img 
                  src={benefit.image} 
                  alt={benefit.title} 
                  className="w-full h-48 object-cover transform group-hover:scale-105 transition-transform duration-500"
                />
              </div>
              <div className="w-full lg:w-1/2 text-center lg:text-left">
                <div className="inline-flex items-center justify-center p-3 bg-brand-50 text-brand-600 rounded-lg mb-4">
                  <benefit.icon className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-bold text-slate-900 mb-2">{benefit.title}</h3>
                <p className="text-slate-600 leading-relaxed">{benefit.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Benefits;