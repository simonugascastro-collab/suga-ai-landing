import React from 'react';
import { ShieldCheck, MessageCircle, PenTool } from 'lucide-react';

const Guarantee: React.FC = () => {
  const guarantees = [
    {
      icon: PenTool,
      text: "Ajustes incluidos después de la entrega"
    },
    {
      icon: MessageCircle,
      text: "Soporte inicial por WhatsApp"
    },
    {
      icon: ShieldCheck,
      text: "Acompañamiento para que tu página quede exactamente como la necesitas"
    }
  ];

  return (
    <section className="py-20 bg-brand-50">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-slate-900 mb-4">Nuestra garantía</h2>
          <p className="text-slate-600">Tu satisfacción y el éxito de tu negocio son nuestra prioridad.</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
          {guarantees.map((item, index) => (
            <div key={index} className="bg-white p-6 rounded-xl shadow-sm border border-brand-100 flex flex-col items-center">
              <div className="w-12 h-12 bg-brand-100 text-brand-600 rounded-full flex items-center justify-center mb-4">
                <item.icon className="w-6 h-6" />
              </div>
              <p className="font-medium text-slate-800">{item.text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Guarantee;