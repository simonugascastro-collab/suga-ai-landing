import React, { useState, useEffect } from 'react';
import { Menu, X } from 'lucide-react';
import Logo from './Logo';

const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setIsOpen(false);
    }
  };

  return (
    <nav className={`fixed top-0 w-full z-40 transition-all duration-300 ${scrolled ? 'bg-white/90 backdrop-blur-md shadow-sm py-4' : 'bg-transparent py-6'}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex justify-between items-center">
        {/* Brand Block */}
        <div className="flex items-center cursor-pointer gap-3" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
          {/* Logo Icon - Adjusted to be smaller (h-10) as requested */}
          <Logo className="h-10 w-10 flex-shrink-0" />
          
          {/* Text Block */}
          <div className="flex flex-col justify-center">
            {/* Brand Name - Bold and prominent */}
            <span className="font-bold text-2xl text-slate-900 leading-none tracking-tight">suga.ai</span>
            {/* Tagline - Subtle grey, smaller font */}
            <span className="text-xs text-slate-500 font-medium tracking-wide mt-0.5">Automatización y presencia digital profesional</span>
          </div>
        </div>

        {/* Desktop Menu */}
        <div className="hidden md:flex items-center space-x-8">
          <button onClick={() => scrollToSection('beneficios')} className="text-slate-600 hover:text-brand-600 font-medium transition-colors">Beneficios</button>
          <button onClick={() => scrollToSection('planes')} className="text-slate-600 hover:text-brand-600 font-medium transition-colors">Planes</button>
          <button onClick={() => scrollToSection('procesos')} className="text-slate-600 hover:text-brand-600 font-medium transition-colors">Procesos</button>
          <button 
            onClick={() => scrollToSection('cotizar-proyecto')}
            className="bg-brand-600 text-white px-6 py-2.5 rounded-full font-semibold hover:bg-brand-700 transition-all shadow-lg shadow-brand-500/30"
          >
            Empezar ahora
          </button>
        </div>

        {/* Mobile Menu Button */}
        <div className="md:hidden">
          <button onClick={() => setIsOpen(!isOpen)} className="text-slate-700 focus:outline-none">
            {isOpen ? <X className="h-8 w-8" /> : <Menu className="h-8 w-8" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      {isOpen && (
        <div className="md:hidden absolute top-full left-0 w-full bg-white border-b border-slate-100 shadow-xl py-4 flex flex-col items-center space-y-4">
          <button onClick={() => scrollToSection('beneficios')} className="text-slate-700 font-medium py-2">Beneficios</button>
          <button onClick={() => scrollToSection('planes')} className="text-slate-700 font-medium py-2">Planes</button>
          <button onClick={() => scrollToSection('procesos')} className="text-slate-700 font-medium py-2">Procesos</button>
          <button 
            onClick={() => scrollToSection('cotizar-proyecto')}
            className="bg-brand-600 text-white px-8 py-3 rounded-full font-semibold w-3/4 mx-auto"
          >
            Empezar ahora
          </button>
        </div>
      )}
    </nav>
  );
};

export default Navbar;