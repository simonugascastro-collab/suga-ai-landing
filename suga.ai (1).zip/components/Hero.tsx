import React from 'react';
import { ChevronRight, ArrowRight } from 'lucide-react';

const Hero: React.FC = () => {
  const scrollTo = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 overflow-hidden bg-slate-50">
      <div className="absolute inset-0 z-0">
        <div className="absolute top-0 right-0 -mr-20 -mt-20 w-96 h-96 rounded-full bg-brand-100 blur-3xl opacity-50"></div>
        <div className="absolute bottom-0 left-0 -ml-20 -mb-20 w-80 h-80 rounded-full bg-blue-100 blur-3xl opacity-50"></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col lg:flex-row items-center">
        <div className="lg:w-1/2 lg:pr-12 text-center lg:text-left mb-12 lg:mb-0">
          <div className="inline-flex items-center px-3 py-1 rounded-full bg-brand-50 text-brand-600 text-sm font-semibold mb-6 border border-brand-100">
            <span className="flex h-2 w-2 rounded-full bg-brand-600 mr-2"></span>
            Servicio Digital Profesional
          </div>
          <h1 className="text-4xl lg:text-6xl font-extrabold text-slate-900 tracking-tight leading-tight mb-6">
            Landing Pages que hacen <span className="text-brand-600">crecer tu negocio</span>
          </h1>
          <p className="text-lg text-slate-600 mb-8 leading-relaxed max-w-2xl mx-auto lg:mx-0">
            Diseñamos sitios web modernos con automatizaciones básicas pensadas para convertir visitantes en clientes. Ideal para negocios locales que buscan profesionalismo y resultados.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
            <button 
              onClick={() => scrollTo('cotizar-proyecto')}
              className="bg-brand-600 text-white px-8 py-4 rounded-full font-bold text-lg hover:bg-brand-700 transition-all shadow-lg shadow-brand-500/30 flex items-center justify-center gap-2"
            >
              Empezar ahora <ArrowRight className="w-5 h-5" />
            </button>
            <button 
              onClick={() => scrollTo('planes')}
              className="bg-white text-slate-700 border border-slate-200 px-8 py-4 rounded-full font-bold text-lg hover:bg-slate-50 hover:border-slate-300 transition-all flex items-center justify-center gap-2"
            >
              Ver planes <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="lg:w-1/2 w-full">
          <div className="relative w-full aspect-[4/3] rounded-2xl shadow-2xl overflow-hidden border border-slate-200 bg-white group">
            <div className="absolute top-0 w-full h-8 bg-slate-100 border-b border-slate-200 flex items-center px-4 space-x-2">
              <div className="w-3 h-3 rounded-full bg-red-400"></div>
              <div className="w-3 h-3 rounded-full bg-yellow-400"></div>
              <div className="w-3 h-3 rounded-full bg-green-400"></div>
            </div>
             {/* Mockup content: Professional Website Mockup */}
             <div className="mt-8 h-full w-full bg-slate-50 overflow-hidden">
                <img 
                    src="https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?auto=format&fit=crop&w=800&q=80" 
                    alt="Ejemplo de Landing Page Moderna" 
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
                {/* Overlay UI elements to simulate specific interface */}
                <div className="absolute top-1/4 left-8 right-8 bg-white/80 backdrop-blur p-6 rounded-xl shadow-lg border border-white/50 animate-fade-in-up">
                    <div className="h-4 w-1/3 bg-slate-800 rounded mb-4"></div>
                    <div className="h-2 w-3/4 bg-slate-300 rounded mb-2"></div>
                    <div className="h-2 w-2/3 bg-slate-300 rounded mb-6"></div>
                    <div className="flex gap-3">
                        <div className="h-8 w-24 bg-brand-500 rounded-lg"></div>
                        <div className="h-8 w-24 bg-slate-200 rounded-lg"></div>
                    </div>
                </div>
             </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;