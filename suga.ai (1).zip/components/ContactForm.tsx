import React, { useState } from 'react';
import { Send } from 'lucide-react';
import Logo from './Logo';

const ContactForm: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    businessName: '',
    industry: '',
    city: '',
    contact: '',
    description: ''
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Construct the specific message format requested
    const message = `Nueva solicitud de cotización 🚀

Nombre: ${formData.name}
Negocio: ${formData.businessName}
Rubro: ${formData.industry}
Ciudad: ${formData.city}
Contacto: ${formData.contact}

Mensaje del proyecto:
${formData.description}`;
    
    const fullMessage = encodeURIComponent(message);
    const whatsappUrl = `https://wa.me/56982081251?text=${fullMessage}`;

    window.open(whatsappUrl, '_blank');
  };

  return (
    <section id="cotizar-proyecto" className="py-24 bg-white">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-3xl shadow-xl border border-slate-100 overflow-hidden">
          <div className="grid grid-cols-1 md:grid-cols-5 h-full">
            
            <div className="bg-brand-600 p-10 text-white md:col-span-2 flex flex-col justify-between">
              <div>
                {/* Logo Container: White background to ensure the blue logo is visible */}
                <div className="bg-white w-fit p-3 rounded-xl shadow-md mb-6">
                  <Logo className="w-10 h-10" />
                </div>
                <h3 className="text-2xl font-bold mb-4">Hablemos de tu proyecto</h3>
                <p className="text-brand-100 mb-8">
                  Déjanos tus datos y te contactaremos para entregarte una propuesta a medida sin compromiso.
                </p>
              </div>
              <div className="space-y-4 text-sm text-brand-100">
                <p>Servicio para todo Chile</p>
                <p>contacto@suga.ai</p>
              </div>
            </div>

            <div className="p-10 md:col-span-3">
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Nombre</label>
                    <input 
                      type="text" 
                      name="name"
                      required
                      value={formData.name}
                      onChange={handleChange}
                      className="w-full px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-brand-500 focus:border-brand-500 outline-none transition-all"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Nombre del Negocio</label>
                    <input 
                      type="text" 
                      name="businessName"
                      required
                      value={formData.businessName}
                      onChange={handleChange}
                      className="w-full px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-brand-500 focus:border-brand-500 outline-none transition-all"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Rubro</label>
                    <input 
                      type="text" 
                      name="industry"
                      placeholder="Ej: Restaurante, Servicios..."
                      required
                      value={formData.industry}
                      onChange={handleChange}
                      className="w-full px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-brand-500 focus:border-brand-500 outline-none transition-all"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Ciudad</label>
                    <input 
                      type="text" 
                      name="city"
                      value={formData.city}
                      onChange={handleChange}
                      className="w-full px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-brand-500 focus:border-brand-500 outline-none transition-all"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Email o WhatsApp</label>
                  <input 
                    type="text" 
                    name="contact"
                    required
                    value={formData.contact}
                    onChange={handleChange}
                    className="w-full px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-brand-500 focus:border-brand-500 outline-none transition-all"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Descripción del Proyecto</label>
                  <textarea 
                    name="description"
                    rows={4}
                    value={formData.description}
                    onChange={handleChange}
                    placeholder="Cuéntanos un poco sobre qué necesitas..."
                    className="w-full px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-brand-500 focus:border-brand-500 outline-none transition-all resize-none"
                  ></textarea>
                </div>

                <button 
                  type="submit" 
                  className="w-full bg-slate-900 text-white font-bold py-3 rounded-lg hover:bg-slate-800 transition-colors flex items-center justify-center gap-2"
                >
                  Solicitar cotización <Send className="w-4 h-4" />
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactForm;