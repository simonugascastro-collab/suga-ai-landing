import React from 'react';
import { CheckCircle2 } from 'lucide-react';

const DetailedBenefits: React.FC = () => {
  const benefits = [
    "Más clientes y solicitudes de contacto",
    "Aumento de cotizaciones desde Google y redes sociales",
    "Integración directa con WhatsApp",
    "Sitios rápidos, modernos y preparados para móviles",
    "Diseño orientado a conversiones",
    "Ideal para emprendedores y pymes locales"
  ];

  return (
    <section className="py-20 bg-slate-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-slate-900 mb-6">¿Por qué elegirnos?</h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-y-4 gap-x-12">
          {benefits.map((benefit, index) => (
            <div key={index} className="flex items-center space-x-3 bg-white p-4 rounded-lg shadow-sm border border-slate-100">
              <CheckCircle2 className="w-6 h-6 text-brand-600 flex-shrink-0" />
              <span className="text-slate-700 font-medium">{benefit}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default DetailedBenefits;