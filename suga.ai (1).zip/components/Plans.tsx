import React from 'react';
import { Check } from 'lucide-react';

const Plans: React.FC = () => {
  const handleQuotePlan = (planName: string) => {
    let message = "";
    const phoneNumber = "56982081251";

    switch (planName) {
      case "Starter":
        message = `Hola 👋 Me gustaría cotizar el Plan Starter — Primera Página.

Estos son mis datos:
Nombre:
Negocio:
Rubro:
Ciudad:

Cuéntame los pasos para continuar `;
        break;
      case "Emprendedor":
        message = `Hola 👋 Quiero cotizar el Plan Emprendedor — Presencia Profesional.

Mis datos son:
Nombre:
Negocio:
Rubro:
Ciudad:

Me interesa mejorar la presencia digital de mi negocio `;
        break;
      case "Profesional":
        message = `Hola 👋 Estoy interesado en el Plan Profesional — Negocio en Crecimiento.

Datos del proyecto:
Nombre:
Negocio:
Rubro:
Ciudad:

Estoy buscando algo más avanzado para mi negocio `;
        break;
      default:
        message = "Hola, quiero consultar por una landing page";
    }

    window.open(`https://wa.me/${phoneNumber}?text=${encodeURIComponent(message)}`, '_blank');
  };

  const plans = [
    {
      name: "Starter",
      price: "$49.990",
      description: "Primera Página",
      features: [
        "Landing page simple de 1 sección",
        "Botón directo a WhatsApp",
        "Diseño moderno y responsivo",
        "Entrega rápida"
      ],
      highlight: false
    },
    {
      name: "Emprendedor",
      price: "$79.990",
      description: "Presencia Profesional",
      features: [
        "Landing multiparte",
        "Formulario + WhatsApp",
        "Sección servicios y beneficios",
        "Textos orientados a conversión",
        "Pequeños ajustes posteriores"
      ],
      highlight: true
    },
    {
      name: "Profesional",
      price: "$99.990",
      description: "Negocio en Crecimiento",
      features: [
        "Landing avanzada",
        "Integraciones básicas",
        "Optimización SEO on-page básica",
        "2 rondas de ajustes"
      ],
      highlight: false
    }
  ];

  return (
    <section id="planes" className="py-24 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold text-slate-900 mb-4">Planes diseñados para ti</h2>
          <p className="text-lg text-slate-600">
            Precios transparentes y accesibles para potenciar tu negocio local.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {plans.map((plan, index) => (
            <div 
              key={index} 
              className={`relative rounded-2xl p-8 flex flex-col ${
                plan.highlight 
                  ? 'bg-white shadow-xl ring-2 ring-brand-500 scale-105 z-10' 
                  : 'bg-white shadow-lg border border-slate-100'
              }`}
            >
              {plan.highlight && (
                <div className="absolute top-0 inset-x-0 flex justify-center -translate-y-1/2 pointer-events-none">
                  <span className="bg-brand-600 text-white px-4 py-1 rounded-full text-sm font-semibold tracking-wide uppercase shadow-sm whitespace-nowrap">
                    Más recomendado
                  </span>
                </div>
              )}
              
              <h3 className="text-2xl font-bold text-slate-900 mb-2">{plan.name}</h3>
              <div className="flex items-baseline mb-4">
                <span className={`font-extrabold text-slate-900 ${plan.price.length > 10 ? 'text-2xl' : 'text-4xl'}`}>{plan.price}</span>
                <span className="text-sm text-slate-500 ml-1">CLP</span>
              </div>
              <p className="text-slate-600 mb-6 text-sm">{plan.description}</p>
              
              <ul className="space-y-4 mb-8 flex-1">
                {plan.features.map((feature, i) => (
                  <li key={i} className="flex items-start">
                    <Check className="w-5 h-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                    <span className="text-slate-600 text-sm">{feature}</span>
                  </li>
                ))}
              </ul>

              <button 
                onClick={() => handleQuotePlan(plan.name)}
                className={`w-full py-3 rounded-xl font-bold transition-all ${
                  plan.highlight
                    ? 'bg-brand-600 text-white hover:bg-brand-700 shadow-lg shadow-brand-500/30'
                    : 'bg-slate-100 text-slate-800 hover:bg-slate-200'
                }`}
              >
                Cotizar este plan
              </button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Plans;