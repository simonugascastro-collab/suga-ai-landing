import React from 'react';
import { ArrowRight, FileText } from 'lucide-react';

const ClosingCTA: React.FC = () => {
  const scrollTo = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="py-24 bg-slate-900 text-white text-center">
      <div className="max-w-4xl mx-auto px-4">
        <h2 className="text-3xl md:text-5xl font-bold mb-8">
          ¿Listo para convertir más visitas en clientes?
        </h2>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <button 
            onClick={() => scrollTo('cotizar-proyecto')}
            className="bg-brand-600 text-white px-8 py-4 rounded-full font-bold text-lg hover:bg-brand-700 transition-all shadow-lg shadow-brand-500/30 flex items-center justify-center gap-2"
          >
            Solicitar cotización <ArrowRight className="w-5 h-5" />
          </button>
          <button 
            onClick={() => scrollTo('planes')}
            className="bg-transparent border border-white/20 text-white px-8 py-4 rounded-full font-bold text-lg hover:bg-white/10 transition-all flex items-center justify-center gap-2"
          >
            Ver planes disponibles <FileText className="w-5 h-5" />
          </button>
        </div>
      </div>
    </section>
  );
};

export default ClosingCTA;