import React from 'react';
import { Search, PenTool, Settings, Upload } from 'lucide-react';

const steps = [
  {
    icon: Search,
    title: "1. Reunión e Info",
    description: "Analizamos tu negocio, objetivos y lo que necesitas transmitir."
  },
  {
    icon: PenTool,
    title: "2. Prototipo",
    description: "Diseñamos una propuesta visual moderna de tu landing page."
  },
  {
    icon: Settings,
    title: "3. Ajustes",
    description: "Refinamos detalles según tu feedback para que quede perfecta."
  },
  {
    icon: Upload,
    title: "4. Publicación",
    description: "Lanzamos tu sitio y lo conectamos con tus redes y WhatsApp."
  }
];

const Process: React.FC = () => {
  return (
    <section id="procesos" className="py-24 bg-white border-t border-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold text-slate-900 mb-4">Nuestro Proceso</h2>
          <p className="text-lg text-slate-600">
            Simple, transparente y sin complicaciones técnicas para ti.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {steps.map((step, index) => (
            <div key={index} className="flex flex-col items-center text-center p-6 bg-slate-50 rounded-2xl border border-slate-100 hover:shadow-md transition-shadow">
              <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center shadow-sm mb-6 border border-slate-100 text-brand-600">
                <step.icon className="w-8 h-8" />
              </div>
              <h3 className="text-lg font-bold text-slate-900 mb-3">{step.title}</h3>
              <p className="text-slate-600 text-sm leading-relaxed">
                {step.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Process;