import React from 'react';
import Navbar from './Navbar';
import Hero from './Hero';
import Benefits from './Benefits';
import Plans from './Plans';
import Guarantee from './Guarantee';
import Process from './Process';
import Testimonials from './Testimonials';
import AIDemo from './AIDemo';
import ClosingCTA from './ClosingCTA';
import ContactForm from './ContactForm';
import WhatsAppButton from './WhatsAppButton';
import Footer from './Footer';

const App: React.FC = () => {
  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-900">
      <Navbar />
      <main>
        <Hero />
        <Benefits />
        <Plans />
        <Guarantee />
        <Process />
        <Testimonials />
        <AIDemo />
        <ClosingCTA />
        <ContactForm />
      </main>
      <Footer />
      <WhatsAppButton />
    </div>
  );
};

export default App;