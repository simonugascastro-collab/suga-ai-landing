import React, { useState } from 'react';
import { Sparkles, Loader2, Monitor } from 'lucide-react';
import { generateLandingContent, GeneratedPreview } from '../services/geminiService';

const AIDemo: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const [loading, setLoading] = useState(false);
  const [preview, setPreview] = useState<GeneratedPreview | null>(null);

  const handleGenerate = async () => {
    if (!prompt.trim()) return;
    setLoading(true);
    try {
      const result = await generateLandingContent(prompt);
      setPreview(result);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  return (
    <section className="py-24 bg-slate-900 text-white overflow-hidden relative">
      {/* Background decoration */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden z-0">
        <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-brand-500 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob"></div>
        <div className="absolute bottom-1/4 right-1/4 w-64 h-64 bg-purple-500 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob animation-delay-2000"></div>
      </div>

      <div className="max-w-4xl mx-auto px-4 relative z-10">
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-slate-800 border border-slate-700 text-brand-400 text-sm font-semibold mb-6">
            <Sparkles className="w-4 h-4" />
            <span>Potenciado por IA</span>
          </div>
          <h2 className="text-3xl lg:text-4xl font-bold mb-4">Visualiza tu idea en segundos</h2>
          <p className="text-slate-400">
            Escribe de qué trata tu negocio y nuestra IA generará una estructura y textos de ejemplo.
          </p>
        </div>

        <div className="bg-slate-800/50 backdrop-blur-sm p-6 rounded-2xl border border-slate-700 shadow-2xl">
            <div className="flex flex-col sm:flex-row gap-4 mb-8">
                <input 
                    type="text" 
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    placeholder="Ej: Cafetería de especialidad con pastelería vegana..." 
                    className="flex-1 bg-slate-900 border border-slate-600 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-brand-500"
                />
                <button 
                    onClick={handleGenerate}
                    disabled={loading || !prompt}
                    className="bg-brand-600 hover:bg-brand-500 disabled:opacity-50 disabled:cursor-not-allowed text-white px-6 py-3 rounded-xl font-bold transition-all flex items-center justify-center gap-2 min-w-[160px]"
                >
                    {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : 'Probar demo IA'}
                </button>
            </div>

            {/* Simulated Preview Area */}
            {preview && (
                <div className="animate-fade-in-up bg-white text-slate-900 rounded-xl overflow-hidden shadow-2xl border border-slate-200">
                    {/* Fake Browser Bar */}
                    <div className="bg-slate-100 border-b border-slate-200 p-3 flex gap-2">
                        <div className="w-3 h-3 rounded-full bg-red-400"></div>
                        <div className="w-3 h-3 rounded-full bg-yellow-400"></div>
                        <div className="w-3 h-3 rounded-full bg-green-400"></div>
                    </div>
                    
                    {/* Preview Content */}
                    <div className="p-8 md:p-12 text-center bg-slate-50">
                        <h3 
                            className="text-3xl md:text-5xl font-extrabold mb-4"
                            style={{ color: preview.primaryColor === '#ffffff' ? '#000' : '#1e293b' }}
                        >
                            {preview.headline}
                        </h3>
                        <p className="text-lg text-slate-600 mb-8 max-w-2xl mx-auto">
                            {preview.subheadline}
                        </p>
                        <button 
                            className="px-8 py-3 rounded-full text-white font-bold shadow-lg transform hover:scale-105 transition-transform"
                            style={{ backgroundColor: preview.primaryColor }}
                        >
                            {preview.ctaText}
                        </button>

                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mt-16 text-left">
                            {preview.featureList.map((feat, i) => (
                                <div key={i} className="bg-white p-4 rounded-lg shadow-sm border border-slate-100">
                                    <div className="w-8 h-8 rounded-full mb-3 flex items-center justify-center bg-slate-100">
                                        <Monitor className="w-4 h-4 text-slate-600" />
                                    </div>
                                    <span className="font-semibold text-slate-800">{feat}</span>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            )}
            
            {!preview && !loading && (
                <div className="h-64 flex flex-col items-center justify-center border-2 border-dashed border-slate-700 rounded-xl bg-slate-800/30 text-slate-500">
                    <Monitor className="w-12 h-12 mb-4 opacity-50" />
                    <p>La vista previa aparecerá aquí</p>
                </div>
            )}
        </div>
      </div>
    </section>
  );
};

export default AIDemo;